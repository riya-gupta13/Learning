﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RAYIN.Migrations
{
    public partial class AddShortDescToProduct : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "shortDesc",
                table: "Product",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "shortDesc",
                table: "Product");
        }
    }
}
