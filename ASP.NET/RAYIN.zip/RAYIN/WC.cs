﻿namespace RAYIN
{
    public class WC
    {
        public static string ImagePath = @"\images\Product\";
    }
}
