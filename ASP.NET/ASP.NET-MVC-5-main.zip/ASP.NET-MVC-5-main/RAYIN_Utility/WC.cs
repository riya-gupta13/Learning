﻿namespace RAYIN_Utility
{
    public class WC
    {
        public static string ImagePath = @"\images\Product\";
        public const string SessionCart = "ShoppingCartSession";
        public const string SessionInquiryId = "InquirySession";
        public const string AdminRole = "Admin";
        public const string CustomerRole = "Customer";
        public static string EmailAdmin = "riya130498@gmail.com";
        public static string CategoryName="Category";
        public static string ApplicationTypeName = "ApplicationType";
        public static string Success = "Success";
        public static string Error = "Error";

    }
}
