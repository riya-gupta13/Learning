﻿namespace RAYIN_Models
{
    public class ShoppingCart
    {
            public int ProductId { get; set; }        
    }
}
