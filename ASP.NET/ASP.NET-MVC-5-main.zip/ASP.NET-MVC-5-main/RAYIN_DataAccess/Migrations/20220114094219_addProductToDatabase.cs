﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RAYIN_DataAccess.Migrations
{
    public partial class addProductToDatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
