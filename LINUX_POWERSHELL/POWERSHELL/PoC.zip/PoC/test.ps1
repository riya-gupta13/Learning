﻿$n = 9
Describe 'check number'{
        It '$n is number'{
            $n | should -Be 9
        } 
}