﻿WriteLog $(__HOSTNAME__) $(__FILE__) $(__LINE__) "I" "This is my log message"
$PSScriptRoot